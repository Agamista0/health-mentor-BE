<?php

namespace App\Http\Controllers\Dashboard\ParentUnit;

use App\Http\Controllers\Controller;
use App\Models\ParentUnit;
use Illuminate\Http\Request;

class ParentUnitController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $parents = ParentUnit::all();
        return view('admin.parent.index',compact('parents'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.parent.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'medical_test_id' => $request->type == 'VitalSigns' ? 'required|exists:medical_tests,id' : '',
            'parent_unit' => 'required|string|max:255',
            'convert_unit' => 'required|numeric',
        ]);
        $parent = new ParentUnit();
        $parent->parent_unit = $validatedData['parent_unit'];;
        $parent->convert_unit = $validatedData['convert_unit'];
        $parent->medical_test_id = $validatedData['medical_test_id'];
        $parent->save();
        return redirect()->route('parents.index')->with('success', __('words.created'));
    }

    public function show(string $id)
    {
        $parent = ParentUnit::findOrFail($id);
        return view('admin.parent.show',compact('parent'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $parent = ParentUnit::findOrFail($id);
        return view('admin.parent.edit',compact('parent'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
       // dd($request->all());
        try {
            $validatedData = $request->validate([
                'medical_test_id' => $request->type == 'VitalSigns' ? 'required|exists:medical_tests,id' : '',
                'parent_unit' => 'required|string|max:255',
                'convert_unit' => 'required|numeric',
            ]);
            $parent = ParentUnit::findOrFail($id);
            $parent->parent_unit = $validatedData['parent_unit'];;
            $parent->convert_unit = $validatedData['convert_unit'];
            $parent->medical_test_id = $validatedData['medical_test_id'];
            $parent->save();

            return redirect()->route('parents.index')->with('success', __('words.updated'));
        } catch (\Exception $e) {
            return $e->getMessage(); // You can handle the exception as per your application's error handling strategy
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $parent = ParentUnit::findOrFail($id);
        $parent->delete();
        return redirect()->route('parents.index')->with('success', __('words.delete'));
    }
}
