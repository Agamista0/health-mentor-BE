<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParentUnit extends Model
{
    use HasFactory;
   protected $fillable =['VitalSigns','parent_unit','convert_unit'];
    public $timestamps = false;

    public function medicalTest(){
        return $this->belongsTo(MedicalTest::class);
    }

}
